package com.god.store_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
