package com.god.store_manager.repository.location;

import com.god.store_manager.model.location.Ward;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WardRepository extends JpaRepository<Ward,Long> {
}
