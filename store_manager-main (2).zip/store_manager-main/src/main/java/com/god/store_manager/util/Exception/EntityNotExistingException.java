package com.god.store_manager.util.Exception;

public class EntityNotExistingException extends RuntimeException{
    public EntityNotExistingException(String message){
        super(message);
    }
}
