package com.god.store_manager.Enum;

public enum Role {
    ROLE_ADMIN,
    ROLE_CUSTOMER
}
